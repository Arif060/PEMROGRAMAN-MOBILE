import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: const Text('My List View'),
        ),
        // body: ListView(
        //   children: [
        //     Container(
        //       width: 100,
        //       height: 250,
        //       margin: const EdgeInsets.only(bottom: 10),
        //       color: Colors.red,
        //     ),
        //     Container(
        //       width: 100,
        //       height: 250,
        //       margin: const EdgeInsets.only(bottom: 10),
        //       color: Colors.blue,
        //     ),
        //     Container(
        //       width: 100,
        //       height: 250,
        //       margin: const EdgeInsets.only(bottom: 10),
        //       color: Colors.green,
        //     ),
        //   ],
        // ),
        body: GridView(
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3,
            childAspectRatio: 1,
            ),
            children: [
              Container(
                margin: const EdgeInsets.all(5),
                color: Colors.red,
              ),
              Container(
                margin: const EdgeInsets.all(5),
                color: Colors.blue,
              ),
              Container(
                margin: const EdgeInsets.all(5),
                color: Colors.green,
              ),
            ],
        ),
      ),
    );
  }
}
