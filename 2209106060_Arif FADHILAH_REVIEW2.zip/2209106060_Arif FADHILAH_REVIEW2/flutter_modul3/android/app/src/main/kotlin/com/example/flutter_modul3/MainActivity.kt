package com.example.flutter_modul3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
